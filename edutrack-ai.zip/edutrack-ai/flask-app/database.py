"""SQLite database layer: schema creation and sample data seeding.
Run `python database.py` to (re)create the database with sample records."""
import os
import random
import sqlite3
from datetime import date, timedelta
from werkzeug.security import generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database", "attendance.db")

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS admin (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    teacher_id INTEGER REFERENCES teachers(id) ON DELETE SET NULL,
    UNIQUE (name, class_id)
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL
);

-- One attendance record per student per day (duplicates are impossible).
CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    date TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('Present','Absent')),
    UNIQUE (student_id, date)
);

CREATE TABLE IF NOT EXISTS marks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    internal REAL CHECK (internal IS NULL OR (internal >= 0 AND internal <= 50)),
    semester REAL CHECK (semester IS NULL OR (semester >= 0 AND semester <= 50)),
    UNIQUE (student_id, subject_id)
);

CREATE TABLE IF NOT EXISTS ml_predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL UNIQUE REFERENCES students(id) ON DELETE CASCADE,
    category TEXT NOT NULL,
    confidence REAL NOT NULL,
    risk_score REAL NOT NULL,
    risk_level TEXT NOT NULL,
    probabilities TEXT NOT NULL,
    suggestions TEXT NOT NULL,
    attendance_pct REAL NOT NULL,
    internal_pct REAL NOT NULL,
    failed_subjects INTEGER NOT NULL,
    created_at TEXT NOT NULL
);
"""


def get_connection():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(seed=True, reset=False):
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = get_connection()
    conn.executescript(SCHEMA)
    conn.commit()
    if seed and conn.execute("SELECT COUNT(*) FROM admin").fetchone()[0] == 0:
        seed_sample_data(conn)
    conn.close()


FIRST = ["Aarav", "Diya", "Karthik", "Meera", "Rohan", "Sneha", "Arjun", "Priya", "Vikram", "Ananya",
         "Suresh", "Lakshmi", "Naveen", "Divya", "Harish", "Keerthi", "Manoj", "Pooja", "Sanjay", "Nisha",
         "Dinesh", "Swathi", "Ganesh", "Revathi"]
LAST = ["Kumar", "Raj", "Iyer", "Nair", "Reddy", "Menon", "Pillai", "Das"]
SUBJECTS = ["Python Programming", "Machine Learning", "Data Structures", "Database Systems", "Mathematics for ML"]


def seed_sample_data(conn):
    rng = random.Random(7)
    ph = generate_password_hash
    conn.execute("INSERT INTO admin (name, username, password_hash) VALUES (?,?,?)",
                 ("System Admin", "admin", ph("admin123")))
    teachers = [("Dr. Ramesh Babu", "teacher1"), ("Ms. Kavitha S", "teacher2"), ("Mr. Anand M", "teacher3")]
    for n, u in teachers:
        conn.execute("INSERT INTO teachers (name,email,username,password_hash) VALUES (?,?,?,?)",
                     (n, u + "@college.edu", u, ph("teacher123")))
    for c in ("AIML-2A", "AIML-2B"):
        conn.execute("INSERT INTO classes (name) VALUES (?)", (c,))
    for cid in (1, 2):
        for i, s in enumerate(SUBJECTS):
            conn.execute("INSERT INTO subjects (name,class_id,teacher_id) VALUES (?,?,?)", (s, cid, (i % 3) + 1))

    # 24 students: 12 per class, each with a hidden "ability" and "attendance habit" used only to create sample data
    students = []
    for i in range(24):
        roll = f"AIML{i + 1:03d}"
        name = f"{FIRST[i]} {rng.choice(LAST)}"
        cid = 1 if i < 12 else 2
        conn.execute("INSERT INTO students (roll_no,name,email,phone,class_id,username,password_hash) VALUES (?,?,?,?,?,?,?)",
                     (roll, name, f"{roll.lower()}@student.edu", f"9{rng.randint(100000000, 999999999)}", cid,
                      roll.lower(), ph("student123")))
        ability = min(95, max(20, rng.gauss(60, 20)))
        habit = min(0.98, max(0.5, 0.5 + ability / 220 + rng.gauss(0, 0.1)))
        students.append((i + 1, cid, ability, habit))

    days, d = [], date.today() - timedelta(days=1)
    while len(days) < 60:
        if d.weekday() < 5:
            days.append(d)
        d -= timedelta(days=1)
    for sid, cid, ability, habit in students:
        for day in days:
            st = "Present" if rng.random() < habit else "Absent"
            conn.execute("INSERT INTO attendance (student_id,date,status) VALUES (?,?,?)", (sid, day.isoformat(), st))
        for sub in range((cid - 1) * 5 + 1, (cid - 1) * 5 + 6):
            internal = max(0, min(50, round((ability + rng.gauss(0, 9)) / 2, 1)))
            semester = max(0, min(50, round((ability * 0.7 + habit * 100 * 0.3 + rng.gauss(0, 8)) / 2, 1)))
            conn.execute("INSERT INTO marks (student_id,subject_id,internal,semester) VALUES (?,?,?,?)",
                         (sid, sub, internal, semester))
    conn.commit()


if __name__ == "__main__":
    init_db(seed=True, reset=True)
    print("Database created with sample data at:", DB_PATH)
