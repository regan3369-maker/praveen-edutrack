"""Machine Learning module (Scikit-learn Random Forest).

PROBLEM : Predict a student's final performance category from early indicators.
CLASSES : Poor, Average, Good, Excellent  (final total % <40, 40-59, 60-74, 75+)
FEATURES: attendance_pct   - overall attendance percentage
          internal_pct     - average internal exam mark, as a percentage
          failed_subjects  - number of subjects with internal marks below 40%
TRAINING DATA: database/training_data.csv. Because no real historical records exist for a new
          project, a SAMPLE dataset (800 simulated past students) is generated on first run.
          Replace the CSV with real past-batch data (same columns) and retrain for real predictions.
"""
import json
import os
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import cross_val_score, train_test_split

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_CSV = os.path.join(BASE_DIR, "database", "training_data.csv")
MODEL_PATH = os.path.join(BASE_DIR, "database", "model.joblib")
METRICS_PATH = os.path.join(BASE_DIR, "database", "metrics.json")

FEATURES = ["attendance_pct", "internal_pct", "failed_subjects"]
LABELS = ["Poor", "Average", "Good", "Excellent"]
_model = None


def to_label(pct):
    return "Excellent" if pct >= 75 else "Good" if pct >= 60 else "Average" if pct >= 40 else "Poor"


def generate_training_data(n=800, seed=42):
    """Create a sample 'past students' dataset. Final result depends on hidden ability + attendance + noise."""
    rng = np.random.default_rng(seed)
    ability = np.clip(rng.normal(60, 22, n), 5, 100)
    attendance = np.clip(0.45 * ability + 42 + rng.normal(0, 12, n), 30, 100)
    internal = np.clip(ability + rng.normal(0, 6, n), 0, 100)
    failed = np.array([(np.clip(rng.normal(i, 10, 5), 0, 100) < 40).sum() for i in internal])
    final = np.clip(0.7 * ability + 0.3 * attendance + rng.normal(0, 5, n), 0, 100)
    df = pd.DataFrame({"attendance_pct": attendance.round(1), "internal_pct": internal.round(1),
                       "failed_subjects": failed, "final_pct": final.round(1)})
    df["result"] = df["final_pct"].apply(to_label)
    df.to_csv(DATA_CSV, index=False)
    return df


def train():
    """Train, test and save the model. Returns a metrics dictionary."""
    global _model
    df = pd.read_csv(DATA_CSV) if os.path.exists(DATA_CSV) else generate_training_data()
    X, y = df[FEATURES], df["result"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
    clf = RandomForestClassifier(n_estimators=150, max_depth=6, random_state=42)
    clf.fit(X_tr, y_tr)
    pred = clf.predict(X_te)
    metrics = {
        "algorithm": "Random Forest Classifier (150 trees, max depth 6)",
        "rows": int(len(df)), "train_rows": int(len(X_tr)), "test_rows": int(len(X_te)),
        "accuracy": round(accuracy_score(y_te, pred) * 100, 1),
        "cv_accuracy": round(cross_val_score(clf, X, y, cv=5).mean() * 100, 1),
        "importances": {f: round(float(v) * 100, 1) for f, v in zip(FEATURES, clf.feature_importances_)},
        "report": classification_report(y_te, pred, output_dict=True, zero_division=0),
        "labels": [l for l in LABELS if l in clf.classes_],
        "confusion": confusion_matrix(y_te, pred, labels=[l for l in LABELS if l in clf.classes_]).tolist(),
        "class_counts": {k: int(v) for k, v in y.value_counts().items()},
    }
    joblib.dump(clf, MODEL_PATH)
    with open(METRICS_PATH, "w") as f:
        json.dump(metrics, f)
    _model = clf
    return metrics


def get_metrics():
    if not os.path.exists(METRICS_PATH):
        train()
    with open(METRICS_PATH) as f:
        return json.load(f)


def get_model():
    global _model
    if _model is None:
        if not os.path.exists(MODEL_PATH):
            train()
        _model = joblib.load(MODEL_PATH)
    return _model


def predict(feats):
    clf = get_model()
    X = pd.DataFrame([[feats[f] for f in FEATURES]], columns=FEATURES)
    proba = clf.predict_proba(X)[0]
    probs = {c: round(float(p) * 100, 1) for c, p in zip(clf.classes_, proba)}
    category = max(probs, key=probs.get)
    risk = (probs.get("Poor", 0) + 0.5 * probs.get("Average", 0)) / 100
    level = "High" if risk >= 0.5 else "Medium" if risk >= 0.25 else "Low"
    return {"category": category, "confidence": probs[category], "probabilities": probs,
            "risk_score": round(risk * 100, 1), "risk_level": level}


def suggestions(feats, category):
    """Advice text chosen from the student's own numbers and the ML-predicted category."""
    tips = []
    if feats["attendance_pct"] < 75:
        tips.append("Attendance is below 75%. Attend every class this month; missed lectures are the biggest avoidable loss.")
    elif feats["attendance_pct"] < 85:
        tips.append("Attendance is acceptable but can improve. Aim for 90% or higher.")
    if feats["failed_subjects"] > 0:
        tips.append(f"You are below 40% in {feats['failed_subjects']} subject(s) internally. Ask the teacher for extra practice and revise basics first.")
    if feats["internal_pct"] < 60:
        tips.append("Plan 1-2 hours of daily revision and solve previous question papers.")
    if category in ("Poor", "Average"):
        tips.append("Meet your class teacher for a personal improvement plan and join doubt-clearing sessions.")
    if category == "Good":
        tips.append("You are on track. Focus on weaker subjects to move into the Excellent band.")
    if category == "Excellent":
        tips.append("Excellent trend. Keep your routine, try mini-projects, and help classmates through peer learning.")
    return tips or ["Keep up the consistent work."]


if __name__ == "__main__":
    generate_training_data()
    m = train()
    print("Accuracy:", m["accuracy"], "% | 5-fold CV:", m["cv_accuracy"], "%")
