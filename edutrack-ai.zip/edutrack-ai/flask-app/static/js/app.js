// Sidebar toggle (mobile)
document.addEventListener("DOMContentLoaded", () => {
  const sb = document.querySelector(".sidebar"), btn = document.querySelector(".menu-btn");
  if (btn && sb) btn.addEventListener("click", () => sb.classList.toggle("open"));

  // Live table search: <input data-filter="#tableId">
  document.querySelectorAll("input[data-filter]").forEach(inp => {
    inp.addEventListener("input", () => {
      const q = inp.value.toLowerCase();
      document.querySelectorAll(inp.dataset.filter + " tbody tr").forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? "" : "none";
      });
    });
  });

  // Confirm dialogs: <form data-confirm="message">
  document.querySelectorAll("form[data-confirm]").forEach(f =>
    f.addEventListener("submit", e => { if (!confirm(f.dataset.confirm)) e.preventDefault(); }));

  // Attendance quick buttons
  document.querySelectorAll("[data-mark-all]").forEach(b => b.addEventListener("click", () =>
    document.querySelectorAll(`input[type=radio][value=${b.dataset.markAll}]`).forEach(r => r.checked = true)));
});

// Chart helpers (Chart.js)
const COLORS = ["#2563eb", "#7c3aed", "#0ea5e9", "#c026d3", "#10b981", "#f59e0b", "#ef4444"];
const CAT_COLORS = {Excellent: "#10b981", Good: "#2563eb", Average: "#f59e0b", Poor: "#ef4444"};
function makeChart(id, type, labels, datasets, opts = {}) {
  const el = document.getElementById(id);
  if (!el || typeof Chart === "undefined") return;
  return new Chart(el, {type, data: {labels, datasets}, options: Object.assign(
    {responsive: true, maintainAspectRatio: false, plugins: {legend: {display: datasets.length > 1 || ["doughnut", "pie"].includes(type)}}}, opts)});
}
const pctAxis = {scales: {y: {beginAtZero: true, max: 100, ticks: {callback: v => v + "%"}}}};
