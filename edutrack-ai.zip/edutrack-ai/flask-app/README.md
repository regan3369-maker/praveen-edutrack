# EduTrack AI - Student Attendance and Marks Monitoring System

Flask + SQLite + Scikit-learn + Bootstrap + Chart.js. Three roles (Admin, Teacher, Student), daily attendance,
internal/semester marks, CSV reports and a Random Forest model that predicts performance and flags at-risk students.

## 1. Folder structure
```
attendance_system/
  app.py            Flask routes, login, role-based access, dashboards
  database.py       SQLite schema + sample data
  model.py          Machine learning (train / test / predict)
  requirements.txt
  templates/        HTML pages (Jinja)
  static/css|js|images/
  database/         attendance.db, training_data.csv, model.joblib (created automatically)
```

## 2. Install and run (VS Code, step by step)
1. Install Python 3.10+ from python.org (tick "Add Python to PATH"). Install VS Code and its "Python" extension.
2. VS Code: File > Open Folder > choose `attendance_system`. Open the terminal with Ctrl + `.
3. Create a virtual environment:
   - Windows: `python -m venv venv` then `venv\Scripts\activate`
   - Mac/Linux: `python3 -m venv venv` then `source venv/bin/activate`
4. Install packages: `pip install -r requirements.txt`
5. Run: `python app.py`
6. Open http://127.0.0.1:5000 in your browser (internet is needed for the Bootstrap/Chart.js CDN files).

The first run automatically creates the database (`database/attendance.db`), fills it with sample data, and trains the
ML model. To rebuild from scratch: delete the `database` folder's `.db`, `.joblib`, `.json` files, or run `python database.py`.

## 3. Sample logins
| Role | Username | Password |
|---|---|---|
| Admin | admin | admin123 |
| Teacher | teacher1, teacher2, teacher3 | teacher123 |
| Student | aiml001 ... aiml024 | student123 |

Sample data: 2 classes, 5 subjects each, 24 students, 60 school days of attendance and internal + semester marks.
Change the passwords after first login (sidebar > Change password).

## 4. Database
Tables: admin, teachers, students, classes, subjects, attendance, marks, ml_predictions.
Foreign keys link students to classes, subjects to classes/teachers, and attendance/marks/predictions to students.
`UNIQUE(student_id, date)` on attendance makes duplicate attendance for one student and day impossible; saving the
same day again updates the record. Marks: internal out of 50 + semester out of 50 = 100.

## 5. The machine learning part (read this for your viva)
- **Goal:** predict a student's final category (Poor, Average, Good, Excellent) from early indicators.
- **Features:** `attendance_pct`, `internal_pct` (average internal mark %), `failed_subjects` (subjects below 40% internally).
- **Training data:** `database/training_data.csv`, 800 rows. No real past-student data exists in a new project, so the
  first run *generates a simulated sample dataset*. Be open about this in your report. To use real data, replace the CSV
  with past-batch records using the same columns plus `result`, then press **Retrain model** (Admin > Model details).
- **Model:** `RandomForestClassifier(n_estimators=150, max_depth=6)`.
- **Testing:** 80/20 stratified train/test split plus 5-fold cross-validation. Accuracy (about 70% on the sample data),
  per-class precision/recall, confusion matrix and feature importance are shown on the Model details page.
- **Prediction:** `predict_proba` gives the probability of each category. The highest is the prediction; risk score =
  P(Poor) + 0.5 x P(Average). Results are stored in `ml_predictions` and shown with charts.
- **Suggestions:** the advice text is chosen from the student's own numbers and the predicted category. It is advice,
  not a prediction.

## 6. Security
Passwords are hashed (Werkzeug), sessions are role-checked on every route, all forms carry CSRF tokens, SQL uses
parameters, inputs are validated, and students can only see their own data. Before real use: set
`SECRET_KEY` as an environment variable and run behind HTTPS with a production server (e.g. waitress or gunicorn).

## 7. Troubleshooting
| Problem | Fix |
|---|---|
| `python` not recognised | Reinstall Python with "Add to PATH", or use `py` (Windows) / `python3` |
| `No module named flask` | Activate the venv, then `pip install -r requirements.txt` |
| PowerShell blocks `activate` | `Set-ExecutionPolicy -Scope Process Bypass`, then activate again |
| Charts or styling missing | You are offline: Bootstrap/Chart.js load from a CDN |
| `database is locked` | Close DB browser tools or other copies of the app |
| Port 5000 in use | `flask run --port 5001` or change `app.run(port=5001)` |
| Login says incorrect | Pick the right role tab; use sample passwords above |
| Want fresh sample data | Run `python database.py` (this erases existing records) |
| Page says 400 | The form token expired: reload the page and submit again |
