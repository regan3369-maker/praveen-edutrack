"""EduTrack AI - Student Attendance and Marks Monitoring System (Flask)."""
import csv
import io
import json
import os
import re
import secrets
import sqlite3
from datetime import date, datetime
from functools import wraps

from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from markupsafe import Markup
from werkzeug.security import check_password_hash, generate_password_hash

import database
import model

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key-before-deployment")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

INT_MAX, SEM_MAX, ATT_LIMIT = 50, 50, 75
ROLE_TABLE = {"admin": "admin", "teacher": "teachers", "student": "students"}
USER_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

database.init_db(seed=True)


# ------------------------------------------------------------------ helpers
def db():
    if "db" not in g:
        g.db = database.get_connection()
    return g.db


@app.teardown_appcontext
def close_db(_):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


@app.before_request
def csrf_protect():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    if request.method == "POST" and not secrets.compare_digest(request.form.get("csrf_token", ""), session["csrf"]):
        abort(400)


@app.context_processor
def inject():
    return {"csrf_input": lambda: Markup(f'<input type="hidden" name="csrf_token" value="{session.get("csrf", "")}">'),
            "ATT_LIMIT": ATT_LIMIT, "INT_MAX": INT_MAX, "SEM_MAX": SEM_MAX}


@app.after_request
def security_headers(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Cache-Control"] = "no-store"
    return resp


def login_required(*roles):
    def deco(f):
        @wraps(f)
        def wrapper(*a, **kw):
            if "uid" not in session:
                return redirect(url_for("login"))
            if roles and session["role"] not in roles:
                abort(403)
            return f(*a, **kw)
        return wrapper
    return deco


@app.errorhandler(400)
@app.errorhandler(403)
@app.errorhandler(404)
def error_page(e):
    return render_template("error.html", code=e.code, message=e.description), e.code


def category_of(pct):
    return model.to_label(pct)


def pct_or_zero(a, b):
    return round(a * 100 / b, 1) if b else 0.0


def parse_date(s):
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def get_classes():
    return db().execute("SELECT * FROM classes ORDER BY name").fetchall()


def pick_class(classes):
    """Resolve the class_id query/form value to a valid class id (defaults to first class)."""
    try:
        cid = int(request.values.get("class_id", 0))
    except ValueError:
        cid = 0
    ids = [c["id"] for c in classes]
    return cid if cid in ids else (ids[0] if ids else None)


def attendance_map():
    rows = db().execute("SELECT student_id, COUNT(*) t, SUM(status='Present') p FROM attendance GROUP BY student_id").fetchall()
    return {r["student_id"]: (r["t"], r["p"] or 0) for r in rows}


def marks_avg_map():
    rows = db().execute("""SELECT student_id, AVG(internal) i, AVG(semester) s,
        AVG((internal+semester)*100.0/?) tot FROM marks WHERE internal IS NOT NULL AND semester IS NOT NULL
        GROUP BY student_id""", (INT_MAX + SEM_MAX,)).fetchall()
    return {r["student_id"]: r for r in rows}


def student_rows(class_id=None, q=""):
    sql = "SELECT s.*, c.name class_name FROM students s JOIN classes c ON c.id=s.class_id WHERE 1=1"
    args = []
    if class_id:
        sql += " AND s.class_id=?"
        args.append(class_id)
    if q:
        sql += " AND (s.name LIKE ? OR s.roll_no LIKE ?)"
        args += [f"%{q}%", f"%{q}%"]
    sql += " ORDER BY s.roll_no"
    att, mk = attendance_map(), marks_avg_map()
    out = []
    for s in db().execute(sql, args).fetchall():
        t, p = att.get(s["id"], (0, 0))
        m = mk.get(s["id"])
        out.append({**dict(s), "att_total": t, "att_pct": pct_or_zero(p, t), "has_att": t > 0,
                    "avg_pct": round(m["tot"], 1) if m else None,
                    "grade": category_of(m["tot"]) if m else None})
    return out


def student_marks(sid):
    rows = db().execute("""SELECT sub.id, sub.name, m.internal, m.semester FROM students st
        JOIN subjects sub ON sub.class_id=st.class_id
        LEFT JOIN marks m ON m.subject_id=sub.id AND m.student_id=st.id
        WHERE st.id=? ORDER BY sub.name""", (sid,)).fetchall()
    out = []
    for r in rows:
        both = r["internal"] is not None and r["semester"] is not None
        total = (r["internal"] + r["semester"]) if both else None
        out.append({"name": r["name"], "internal": r["internal"], "semester": r["semester"], "total": total,
                    "pct": round(total * 100 / (INT_MAX + SEM_MAX), 1) if both else None,
                    "result": ("Pass" if total >= 40 else "Fail") if both else "Pending"})
    return out


def features_for(sid):
    """Build the ML feature vector for one student from database records (None if not enough data)."""
    t = db().execute("SELECT COUNT(*) t, SUM(status='Present') p FROM attendance WHERE student_id=?", (sid,)).fetchone()
    ints = [m["internal"] * 100 / INT_MAX for m in student_marks(sid) if m["internal"] is not None]
    if not t["t"] or not ints:
        return None
    return {"attendance_pct": pct_or_zero(t["p"] or 0, t["t"]), "internal_pct": round(sum(ints) / len(ints), 1),
            "failed_subjects": sum(1 for v in ints if v < 40)}


def run_prediction(sid):
    feats = features_for(sid)
    if not feats:
        return False
    res = model.predict(feats)
    tips = model.suggestions(feats, res["category"])
    db().execute("""INSERT INTO ml_predictions (student_id,category,confidence,risk_score,risk_level,probabilities,
        suggestions,attendance_pct,internal_pct,failed_subjects,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(student_id) DO UPDATE SET category=excluded.category, confidence=excluded.confidence,
        risk_score=excluded.risk_score, risk_level=excluded.risk_level, probabilities=excluded.probabilities,
        suggestions=excluded.suggestions, attendance_pct=excluded.attendance_pct, internal_pct=excluded.internal_pct,
        failed_subjects=excluded.failed_subjects, created_at=excluded.created_at""",
                 (sid, res["category"], res["confidence"], res["risk_score"], res["risk_level"],
                  json.dumps(res["probabilities"]), json.dumps(tips), feats["attendance_pct"],
                  feats["internal_pct"], feats["failed_subjects"], datetime.now().strftime("%Y-%m-%d %H:%M")))
    db().commit()
    return True


def get_prediction(sid):
    r = db().execute("SELECT * FROM ml_predictions WHERE student_id=?", (sid,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["probabilities"] = json.loads(d["probabilities"])
    d["suggestions"] = json.loads(d["suggestions"])
    return d


def clean_text(v, mx=60):
    return " ".join((v or "").split())[:mx]


# --------------------------------------------------------------------- auth
@app.route("/")
def index():
    return redirect(url_for("dashboard"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        role = request.form.get("role", "")
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if role in ROLE_TABLE and USER_RE.match(username):
            user = db().execute(f"SELECT * FROM {ROLE_TABLE[role]} WHERE username=?", (username,)).fetchone()
            if user and check_password_hash(user["password_hash"], password):
                session.clear()
                session.update(uid=user["id"], role=role, name=user["name"], csrf=secrets.token_hex(16))
                return redirect(url_for("dashboard"))
        flash("Incorrect role, username or password.", "danger")
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required()
def dashboard():
    return redirect(url_for({"admin": "admin_dashboard", "teacher": "teacher_dashboard",
                             "student": "student_dashboard"}[session["role"]]))


@app.route("/change-password", methods=["GET", "POST"])
@login_required()
def change_password():
    if request.method == "POST":
        table = ROLE_TABLE[session["role"]]
        user = db().execute(f"SELECT * FROM {table} WHERE id=?", (session["uid"],)).fetchone()
        new = request.form.get("new_password", "")
        if not check_password_hash(user["password_hash"], request.form.get("old_password", "")):
            flash("Current password is incorrect.", "danger")
        elif len(new) < 6 or new != request.form.get("confirm_password", ""):
            flash("New password must be at least 6 characters and match the confirmation.", "danger")
        else:
            db().execute(f"UPDATE {table} SET password_hash=? WHERE id=?", (generate_password_hash(new), user["id"]))
            db().commit()
            flash("Password changed successfully.", "success")
            return redirect(url_for("dashboard"))
    return render_template("change_password.html")


# -------------------------------------------------------------------- admin
@app.route("/admin")
@login_required("admin")
def admin_dashboard():
    d = db()
    count = lambda t: d.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
    rows = student_rows()
    att_tot = d.execute("SELECT COUNT(*) t, SUM(status='Present') p FROM attendance").fetchone()
    below = [r for r in rows if r["has_att"] and r["att_pct"] < ATT_LIMIT]
    graded = [r for r in rows if r["avg_pct"] is not None]
    class_att = {}
    for r in rows:
        class_att.setdefault(r["class_name"], []).append(r["att_pct"])
    subj = d.execute("""SELECT sub.name || ' (' || c.name || ')' n, AVG((m.internal+m.semester)*100.0/?) a
        FROM marks m JOIN subjects sub ON sub.id=m.subject_id JOIN classes c ON c.id=sub.class_id
        WHERE m.internal IS NOT NULL AND m.semester IS NOT NULL GROUP BY sub.id ORDER BY sub.class_id, sub.name""",
                     (INT_MAX + SEM_MAX,)).fetchall()
    grades = {k: 0 for k in model.LABELS}
    for r in graded:
        grades[r["grade"]] += 1
    stats = {"students": count("students"), "teachers": count("teachers"), "classes": count("classes"),
             "subjects": count("subjects"), "overall_att": pct_or_zero(att_tot["p"] or 0, att_tot["t"]),
             "below": len(below), "avg_marks": round(sum(r["avg_pct"] for r in graded) / len(graded), 1) if graded else 0,
             "at_risk": d.execute("SELECT COUNT(*) FROM ml_predictions WHERE risk_level='High'").fetchone()[0]}
    chart = {"class_att": {k: round(sum(v) / len(v), 1) for k, v in class_att.items()},
             "subject_avg": {r["n"]: round(r["a"], 1) for r in subj}, "grades": grades}
    return render_template("admin_dashboard.html", stats=stats, chart=chart, below=below[:8])


@app.route("/students")
@login_required("admin", "teacher")
def students():
    classes = get_classes()
    cid = request.args.get("class_id", type=int)
    q = clean_text(request.args.get("q", ""), 40)
    return render_template("students.html", rows=student_rows(cid, q), classes=classes, cid=cid, q=q)


def validate_student(form, editing=False, sid=None):
    data = {"roll_no": clean_text(form.get("roll_no"), 20).upper(), "name": clean_text(form.get("name")),
            "email": clean_text(form.get("email"), 80), "phone": clean_text(form.get("phone"), 15),
            "username": clean_text(form.get("username"), 30), "class_id": form.get("class_id", type=int)}
    pw, errs = form.get("password", ""), []
    if not re.match(r"^[A-Z0-9-]{3,20}$", data["roll_no"]):
        errs.append("Roll number must be 3-20 letters, digits or hyphens.")
    if len(data["name"]) < 2:
        errs.append("Name is required.")
    if data["email"] and not EMAIL_RE.match(data["email"]):
        errs.append("Email address is not valid.")
    if data["phone"] and not re.match(r"^\d{7,15}$", data["phone"]):
        errs.append("Phone must contain 7-15 digits.")
    if not USER_RE.match(data["username"]):
        errs.append("Username must be 3-30 letters, digits, dot, dash or underscore.")
    if not db().execute("SELECT 1 FROM classes WHERE id=?", (data["class_id"],)).fetchone():
        errs.append("Choose a valid class.")
    if (not editing or pw) and len(pw) < 6:
        errs.append("Password must be at least 6 characters.")
    return data, pw, errs


@app.route("/students/add", methods=["GET", "POST"])
@app.route("/students/<int:sid>/edit", methods=["GET", "POST"])
@login_required("admin")
def student_form(sid=None):
    student = db().execute("SELECT * FROM students WHERE id=?", (sid,)).fetchone() if sid else None
    if sid and not student:
        abort(404)
    if request.method == "POST":
        data, pw, errs = validate_student(request.form, editing=bool(sid))
        if not errs:
            try:
                if sid:
                    db().execute("UPDATE students SET roll_no=?,name=?,email=?,phone=?,class_id=?,username=? WHERE id=?",
                                 (*[data[k] for k in ("roll_no", "name", "email", "phone", "class_id", "username")], sid))
                    if pw:
                        db().execute("UPDATE students SET password_hash=? WHERE id=?", (generate_password_hash(pw), sid))
                else:
                    db().execute("INSERT INTO students (roll_no,name,email,phone,class_id,username,password_hash) VALUES (?,?,?,?,?,?,?)",
                                 (*[data[k] for k in ("roll_no", "name", "email", "phone", "class_id", "username")],
                                  generate_password_hash(pw)))
                db().commit()
                flash("Student saved.", "success")
                return redirect(url_for("students"))
            except sqlite3.IntegrityError:
                errs.append("Roll number or username already exists.")
        for e in errs:
            flash(e, "danger")
        student = data
    return render_template("student_form.html", student=student, classes=get_classes(), editing=bool(sid))


@app.route("/students/<int:sid>/delete", methods=["POST"])
@login_required("admin")
def student_delete(sid):
    db().execute("DELETE FROM students WHERE id=?", (sid,))
    db().commit()
    flash("Student deleted along with their attendance, marks and prediction.", "success")
    return redirect(url_for("students"))


@app.route("/teachers", methods=["GET", "POST"])
@login_required("admin")
def teachers():
    if request.method == "POST":
        name, email = clean_text(request.form.get("name")), clean_text(request.form.get("email"), 80)
        username, pw = clean_text(request.form.get("username"), 30), request.form.get("password", "")
        if len(name) < 2 or not USER_RE.match(username) or len(pw) < 6 or (email and not EMAIL_RE.match(email)):
            flash("Enter a name, a valid username, a valid email (optional) and a password of 6+ characters.", "danger")
        else:
            try:
                db().execute("INSERT INTO teachers (name,email,username,password_hash) VALUES (?,?,?,?)",
                             (name, email, username, generate_password_hash(pw)))
                db().commit()
                flash("Teacher account created.", "success")
            except sqlite3.IntegrityError:
                flash("That username is already taken.", "danger")
        return redirect(url_for("teachers"))
    rows = db().execute("""SELECT t.*, GROUP_CONCAT(s.name || ' (' || c.name || ')', ', ') subjects FROM teachers t
        LEFT JOIN subjects s ON s.teacher_id=t.id LEFT JOIN classes c ON c.id=s.class_id GROUP BY t.id ORDER BY t.name""").fetchall()
    return render_template("teachers.html", rows=rows)


@app.route("/teachers/<int:tid>/delete", methods=["POST"])
@login_required("admin")
def teacher_delete(tid):
    db().execute("DELETE FROM teachers WHERE id=?", (tid,))
    db().commit()
    flash("Teacher removed. Their subjects are now unassigned.", "success")
    return redirect(url_for("teachers"))


@app.route("/academics", methods=["GET", "POST"])
@login_required("admin")
def academics():
    if request.method == "POST":
        kind = request.form.get("kind")
        try:
            if kind == "class":
                n = clean_text(request.form.get("name"), 30)
                if len(n) < 2:
                    raise ValueError("Class name is required.")
                db().execute("INSERT INTO classes (name) VALUES (?)", (n,))
            elif kind == "subject":
                n = clean_text(request.form.get("name"), 60)
                cid, tid = request.form.get("class_id", type=int), request.form.get("teacher_id", type=int)
                if len(n) < 2 or not cid:
                    raise ValueError("Subject name and class are required.")
                db().execute("INSERT INTO subjects (name,class_id,teacher_id) VALUES (?,?,?)", (n, cid, tid))
            db().commit()
            flash("Saved.", "success")
        except ValueError as e:
            flash(str(e), "danger")
        except sqlite3.IntegrityError:
            flash("That entry already exists (or the class/teacher is invalid).", "danger")
        return redirect(url_for("academics"))
    subs = db().execute("""SELECT s.*, c.name class_name, t.name teacher_name FROM subjects s JOIN classes c ON c.id=s.class_id
        LEFT JOIN teachers t ON t.id=s.teacher_id ORDER BY c.name, s.name""").fetchall()
    classes = db().execute("SELECT c.*, (SELECT COUNT(*) FROM students WHERE class_id=c.id) n FROM classes c ORDER BY name").fetchall()
    return render_template("academics.html", classes=classes, subjects=subs,
                           teachers=db().execute("SELECT * FROM teachers ORDER BY name").fetchall())


@app.route("/classes/<int:cid>/delete", methods=["POST"])
@login_required("admin")
def class_delete(cid):
    try:
        db().execute("DELETE FROM classes WHERE id=?", (cid,))
        db().commit()
        flash("Class deleted.", "success")
    except sqlite3.IntegrityError:
        flash("This class still has students. Move or delete them first.", "danger")
    return redirect(url_for("academics"))


@app.route("/subjects/<int:sid>/delete", methods=["POST"])
@login_required("admin")
def subject_delete(sid):
    db().execute("DELETE FROM subjects WHERE id=?", (sid,))
    db().commit()
    flash("Subject deleted.", "success")
    return redirect(url_for("academics"))


@app.route("/model", methods=["GET", "POST"])
@login_required("admin")
def model_info():
    if request.method == "POST":
        m = model.train()
        flash(f"Model retrained. Test accuracy: {m['accuracy']}%.", "success")
        return redirect(url_for("model_info"))
    return render_template("model_info.html", m=model.get_metrics(), features=model.FEATURES)


# ------------------------------------------------------------------ teacher
@app.route("/teacher")
@login_required("teacher")
def teacher_dashboard():
    d, tid = db(), session["uid"]
    rows = student_rows()
    today = date.today().isoformat()
    marked = d.execute("SELECT COUNT(DISTINCT student_id) FROM attendance WHERE date=?", (today,)).fetchone()[0]
    my_subjects = d.execute("""SELECT s.id, s.name, c.name class_name FROM subjects s JOIN classes c ON c.id=s.class_id
        WHERE s.teacher_id=? ORDER BY c.name, s.name""", (tid,)).fetchall()
    risk = d.execute("""SELECT s.id, s.name, s.roll_no, c.name class_name, p.category, p.risk_score, p.risk_level
        FROM ml_predictions p JOIN students s ON s.id=p.student_id JOIN classes c ON c.id=s.class_id
        WHERE p.risk_level='High' ORDER BY p.risk_score DESC LIMIT 8""").fetchall()
    below = [r for r in rows if r["has_att"] and r["att_pct"] < ATT_LIMIT]
    class_att = {}
    for r in rows:
        class_att.setdefault(r["class_name"], []).append(r["att_pct"])
    return render_template("teacher_dashboard.html", total=len(rows), marked=marked, today=today, subjects=my_subjects,
                           risk=risk, below=below[:8], below_n=len(below),
                           class_att={k: round(sum(v) / len(v), 1) for k, v in class_att.items()})


@app.route("/attendance", methods=["GET", "POST"])
@login_required("teacher", "admin")
def attendance():
    classes = get_classes()
    cid = pick_class(classes)
    day = parse_date(request.values.get("date")) or date.today()
    if day > date.today():
        flash("Future dates are not allowed. Showing today instead.", "warning")
        day = date.today()
    studs = db().execute("SELECT * FROM students WHERE class_id=? ORDER BY roll_no", (cid,)).fetchall()
    if request.method == "POST":
        for s in studs:
            status = request.form.get(f"status_{s['id']}", "Present")
            if status not in ("Present", "Absent"):
                abort(400)
            db().execute("""INSERT INTO attendance (student_id,date,status) VALUES (?,?,?)
                ON CONFLICT(student_id,date) DO UPDATE SET status=excluded.status""", (s["id"], day.isoformat(), status))
        db().commit()
        flash(f"Attendance for {day.strftime('%d %b %Y')} saved.", "success")
        return redirect(url_for("attendance", class_id=cid, date=day.isoformat()))
    existing = {r["student_id"]: r["status"] for r in db().execute(
        "SELECT student_id, status FROM attendance WHERE date=?", (day.isoformat(),)).fetchall()}
    att = attendance_map()
    rows = [{**dict(s), "status": existing.get(s["id"], "Present"), "recorded": s["id"] in existing,
             "pct": pct_or_zero(att.get(s["id"], (0, 0))[1], att.get(s["id"], (0, 0))[0])} for s in studs]
    return render_template("attendance.html", classes=classes, cid=cid, day=day.isoformat(), rows=rows,
                           today=date.today().isoformat())


@app.route("/marks", methods=["GET", "POST"])
@login_required("teacher", "admin")
def marks():
    if session["role"] == "admin":
        subs = db().execute("SELECT s.*, c.name class_name FROM subjects s JOIN classes c ON c.id=s.class_id ORDER BY c.name, s.name").fetchall()
    else:
        subs = db().execute("""SELECT s.*, c.name class_name FROM subjects s JOIN classes c ON c.id=s.class_id
            WHERE s.teacher_id=? ORDER BY c.name, s.name""", (session["uid"],)).fetchall()
    ids = [s["id"] for s in subs]
    subject_id = request.values.get("subject_id", type=int)
    subject_id = subject_id if subject_id in ids else (ids[0] if ids else None)
    subject = next((s for s in subs if s["id"] == subject_id), None)
    rows = []
    if subject:
        studs = db().execute("SELECT * FROM students WHERE class_id=? ORDER BY roll_no", (subject["class_id"],)).fetchall()
        if request.method == "POST":
            parsed, errs = [], []
            for s in studs:
                vals = []
                for field, mx in (("internal", INT_MAX), ("semester", SEM_MAX)):
                    raw = request.form.get(f"{field}_{s['id']}", "").strip()
                    if raw == "":
                        vals.append(None)
                        continue
                    try:
                        v = float(raw)
                        if not 0 <= v <= mx:
                            raise ValueError
                        vals.append(round(v, 1))
                    except ValueError:
                        errs.append(f"{s['name']}: {field} marks must be a number from 0 to {mx}.")
                        vals.append(None)
                parsed.append((s["id"], *vals))
            if errs:
                for e in errs:
                    flash(e, "danger")
            else:
                for sid, i, se in parsed:
                    db().execute("""INSERT INTO marks (student_id,subject_id,internal,semester) VALUES (?,?,?,?)
                        ON CONFLICT(student_id,subject_id) DO UPDATE SET internal=excluded.internal, semester=excluded.semester""",
                                 (sid, subject_id, i, se))
                db().commit()
                flash("Marks saved.", "success")
                return redirect(url_for("marks", subject_id=subject_id))
        existing = {r["student_id"]: r for r in db().execute("SELECT * FROM marks WHERE subject_id=?", (subject_id,)).fetchall()}
        for s in studs:
            m = existing.get(s["id"])
            i = request.form.get(f"internal_{s['id']}") if request.method == "POST" else (m["internal"] if m else None)
            se = request.form.get(f"semester_{s['id']}") if request.method == "POST" else (m["semester"] if m else None)
            rows.append({**dict(s), "internal": "" if i is None else i, "semester": "" if se is None else se})
    return render_template("marks.html", subjects=subs, subject=subject, rows=rows)


def report_data(cid, month):
    start, end = f"{month}-01", f"{month}-31"
    att = db().execute("""SELECT s.id, s.roll_no, s.name, COUNT(a.id) days, COALESCE(SUM(a.status='Present'),0) present
        FROM students s LEFT JOIN attendance a ON a.student_id=s.id AND a.date BETWEEN ? AND ?
        WHERE s.class_id=? GROUP BY s.id ORDER BY s.roll_no""", (start, end, cid)).fetchall()
    att_rows = [{"roll_no": r["roll_no"], "name": r["name"], "days": r["days"], "present": r["present"],
                 "absent": r["days"] - r["present"], "pct": pct_or_zero(r["present"], r["days"])} for r in att]
    mk_rows = [r for r in student_rows(cid)]
    return att_rows, mk_rows


@app.route("/reports")
@login_required("teacher", "admin")
def reports():
    classes = get_classes()
    cid = pick_class(classes)
    month = request.args.get("month") or date.today().strftime("%Y-%m")
    if not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", month):
        month = date.today().strftime("%Y-%m")
    att_rows, mk_rows = report_data(cid, month) if cid else ([], [])
    return render_template("reports.html", classes=classes, cid=cid, month=month, att_rows=att_rows, mk_rows=mk_rows)


@app.route("/reports/download")
@login_required("teacher", "admin")
def report_download():
    cid, kind = request.args.get("class_id", type=int), request.args.get("kind")
    month = request.args.get("month", "")
    if not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", month) or kind not in ("attendance", "marks"):
        abort(400)
    att_rows, mk_rows = report_data(cid, month)
    buf = io.StringIO()
    w = csv.writer(buf)
    if kind == "attendance":
        w.writerow(["Roll No", "Name", "Days Recorded", "Present", "Absent", "Attendance %", "Below 75%"])
        for r in att_rows:
            w.writerow([r["roll_no"], r["name"], r["days"], r["present"], r["absent"], r["pct"],
                        "Yes" if r["days"] and r["pct"] < ATT_LIMIT else "No"])
    else:
        w.writerow(["Roll No", "Name", "Overall Attendance %", "Average Total Marks %", "Grade"])
        for r in mk_rows:
            w.writerow([r["roll_no"], r["name"], r["att_pct"], r["avg_pct"] if r["avg_pct"] is not None else "", r["grade"] or ""])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={kind}_report_{month}.csv"})


@app.route("/predictions", methods=["GET", "POST"])
@login_required("teacher", "admin")
def predictions():
    classes = get_classes()
    cid = request.values.get("class_id", type=int)
    if request.method == "POST":
        ids = [r["id"] for r in db().execute("SELECT id FROM students" + (" WHERE class_id=?" if cid else ""),
                                              (cid,) if cid else ()).fetchall()]
        done = sum(1 for sid in ids if run_prediction(sid))
        flash(f"ML predictions updated for {done} of {len(ids)} students (students without data are skipped).", "success")
        return redirect(url_for("predictions", class_id=cid or ""))
    sql = """SELECT s.id, s.name, s.roll_no, c.name class_name, p.* FROM ml_predictions p JOIN students s ON s.id=p.student_id
        JOIN classes c ON c.id=s.class_id""" + (" WHERE s.class_id=?" if cid else "") + " ORDER BY p.risk_score DESC"
    rows = db().execute(sql, (cid,) if cid else ()).fetchall()
    dist = {k: 0 for k in model.LABELS}
    for r in rows:
        dist[r["category"]] += 1
    return render_template("predictions.html", rows=rows, dist=dist, classes=classes, cid=cid)


# ------------------------------------------------------------------ student
def student_context(sid):
    d = db()
    s = d.execute("SELECT s.*, c.name class_name FROM students s JOIN classes c ON c.id=s.class_id WHERE s.id=?", (sid,)).fetchone()
    if not s:
        abort(404)
    t = d.execute("SELECT COUNT(*) t, SUM(status='Present') p FROM attendance WHERE student_id=?", (sid,)).fetchone()
    present = t["p"] or 0
    monthly = d.execute("""SELECT substr(date,1,7) m, COUNT(*) t, SUM(status='Present') p FROM attendance
        WHERE student_id=? GROUP BY m ORDER BY m""", (sid,)).fetchall()
    recent = d.execute("SELECT date, status FROM attendance WHERE student_id=? ORDER BY date DESC LIMIT 14", (sid,)).fetchall()
    mk = student_marks(sid)
    done = [m for m in mk if m["pct"] is not None]
    run_prediction(sid)  # keep prediction fresh with the latest data
    return {"s": s, "total_days": t["t"], "present": present, "absent": t["t"] - present,
            "att_pct": pct_or_zero(present, t["t"]), "monthly": [{"m": r["m"], "pct": pct_or_zero(r["p"] or 0, r["t"])} for r in monthly],
            "recent": recent, "marks": mk,
            "avg_pct": round(sum(m["pct"] for m in done) / len(done), 1) if done else None,
            "weak": [m["name"] for m in mk if m["pct"] is not None and m["pct"] < 50],
            "pred": get_prediction(sid)}


@app.route("/student")
@login_required("student")
def student_dashboard():
    return render_template("student_dashboard.html", staff_view=False, **student_context(session["uid"]))


@app.route("/report/student/<int:sid>")
@login_required("admin", "teacher")
def student_report(sid):
    return render_template("student_dashboard.html", staff_view=True, **student_context(sid))


if __name__ == "__main__":
    app.run(debug=True)
