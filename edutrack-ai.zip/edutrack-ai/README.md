# EduTrack AI - Student Attendance and Marks Monitoring System

A 2nd-year AI & ML diploma project. Teachers manage attendance and marks; a Scikit-learn Random Forest predicts
student performance and flags students at risk.

## Contents
| Folder | What it is |
|---|---|
| `flask-app/` | Full system: Flask + SQLite + Scikit-learn + Bootstrap + Chart.js (admin, teacher and student roles) |
| `web-demo/` | Three browser-only demo pages (no server): `index.html` (all roles), `admin.html`, `teacher.html` |

## Run the Flask app
```bash
cd flask-app
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000. The database, sample data and ML model are created on first run.
Full instructions, ML explanation and troubleshooting: see `flask-app/README.md`.

## Sample logins
Admin `admin / admin123` | Teacher `teacher1 / teacher123` | Student `aiml001 / student123`

## Run the web demos
Open any file in `web-demo/` in a browser (internet needed for the Chart.js CDN). Data is stored in the browser only.
To host them free, enable GitHub Pages (Settings > Pages > Deploy from branch > `main`, folder `/web-demo` is not offered,
so use `/(root)` and open `/web-demo/index.html`).

## Note on the ML data
The training data is a simulated sample so the project runs out of the box. Replace
`flask-app/database/training_data.csv` with real past-batch data and retrain for real predictions.
